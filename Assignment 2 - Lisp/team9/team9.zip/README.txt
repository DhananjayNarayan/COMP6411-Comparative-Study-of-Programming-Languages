Assignment 2 on Lisp: Names and ID’s of all contributing members in the team. 

1. Name: Tanzia Ahmed
   ID: 40166924
2. Name: Abdul Shaik
   ID: 40182726
3. Name: Dhananjay Narayan
   ID: 40164521
4. Name: Nadib Hussain
   ID: 40186920
